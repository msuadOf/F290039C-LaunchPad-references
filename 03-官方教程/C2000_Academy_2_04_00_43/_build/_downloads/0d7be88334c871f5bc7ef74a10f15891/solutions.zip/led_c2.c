/*********************************************************************
* Filename: led_c2.c                                                 *
*                                                                    *
* Author: David M. Alter, Texas Instruments Inc.                     *
*                                                                    *
* Last Modified: 05/03/01                                            *
*                                                                    *
* Description: This program cycles the LED's on the F2407 EVM board  *
* at a 250ms rate.  GP Timer2 is used to trigger a period match      *
* interrupt and provide the clocking for the LED updates.            *
*                                                                    *
* History:                                                           *
*   led_c1.c: 10/24/00, original version                             *
*   led_c2.c: 05/03/01, fixed WSGR write value error                 *
*********************************************************************/

/* Address Definitions */
#include        "f2407_c.h"

#define         DAC0    port0000        /* EVM DAC reg 0 */
ioport unsigned port0000;               /* C2xx compiler specific keyword */
#define         DAC1    port0001        /* EVM DAC reg 1 */
ioport unsigned port0001;               /* C2xx compiler specific keyword */
#define         DAC2    port0002        /* EVM DAC reg 2 */
ioport unsigned port0002;               /* C2xx compiler specific keyword */
#define         DAC3    port0003        /* EVM DAC reg 3 */
ioport unsigned port0003;               /* C2xx compiler specific keyword */
#define         DACUD   port0004        /* EVM DAC update reg */
ioport unsigned port0004;               /* C2xx compiler specific keyword */
#define         DIPSWCH port0008        /* EVM 4 position DIP switch */
ioport unsigned port0008;               /* C2xx compiler specific keyword */
#define         LED     port000C        /* EVM LED bank */
ioport unsigned port000C;               /* C2xx compiler specific keyword */


/* Constant Definitions */
#define         LED_prd     58594       /* gives a 250ms LED update rate with
                                           a 1/128 timer prescaler @ 30MHz */
/* Global Variable Definitions */
unsigned int    LED_index;              /* LED_index */


/******************** RESET AND INTERRUPT VECTORS *********************/
    asm("       .sect   \"vectors\"                            ");
    asm("       .ref    _c_int0                                ");

    asm("         B     _c_int0       ;00h reset               ");
    asm("_int1    B     _int1         ;02h INT1                ");
    asm("_int2    B     _int2         ;04h INT2                ");
    asm("_int3    B     _gisr3        ;06h INT3                ");
    asm("_int4    B     _int4         ;08h INT4                ");
    asm("_int5    B     _int5         ;0Ah INT5                ");
    asm("_int6    B     _int6         ;0Ch INT6                ");
    asm("_int7    B     _int7         ;0Eh reserved            ");
    asm("_int8    B     _int8         ;10h INT8  user-defined  ");
    asm("_int9    B     _int9         ;12h INT9  user-defined  ");
    asm("_int10   B     _int10        ;14h INT10 user defined  ");
    asm("_int11   B     _int11        ;16h INT11 user defined  ");
    asm("_int12   B     _int12        ;18h INT12 user defined  ");
    asm("_int13   B     _int13        ;1Ah INT13 user defined  ");
    asm("_int14   B     _int14        ;1Ch INT14 user defined  ");
    asm("_int15   B     _int15        ;1Eh INT15 user defined  ");
    asm("_int16   B     _int16        ;20h INT16 user defined  ");
    asm("_int17   B     _int17        ;22h TRAP                ");
    asm("_int18   B     _int18        ;24h NMI                 ");
    asm("_int19   B     _int19        ;26h reserved            ");
    asm("_int20   B     _int20        ;28h INT20 user defined  ");
    asm("_int21   B     _int21        ;2Ah INT21 user defined  ");
    asm("_int22   B     _int22        ;2Ch INT22 user defined  ");
    asm("_int23   B     _int23        ;2Eh INT23 user defined  ");
    asm("_int24   B     _int24        ;30h INT24 user defined  ");
    asm("_int25   B     _int25        ;32h INT25 user defined  ");
    asm("_int26   B     _int26        ;34h INT26 user defined  ");
    asm("_int27   B     _int27        ;36h INT27 user defined  ");
    asm("_int28   B     _int28        ;38h INT28 user defined  ");
    asm("_int29   B     _int29        ;3Ah INT29 user defined  ");
    asm("_int30   B     _int30        ;3Ch INT30 user defined  ");
    asm("_int31   B     _int31        ;3Eh INT31 user defined  ");

    asm("         .text               ;return to .text for C   ");


/****************************** MAIN ROUTINE ***************************/
void main(void)
{

/* Setup the clock module */
    *SCSR1 = 0x81FD;                   /* PLL x4, CLKOUT=CPUCLK, clear ILLADR bit */
    *SCSR2 = (*SCSR2 | 0x0003) & 0xFFDF;
                                       /* XMIF normal mde, SARAM mapped to prog and data */

/* Disable the watchdog */
    *WDCR  = 0x00E8;                   /* disable the dog */

/* Set wait-states on external memory interface */
    WSGR = 0x0040;                     /* 0 WS data and prog, 1 WS i/o */

/* Setup shared I/O pins */
    *MCRA = 0x0000;                    /* group A pins */
    *MCRB = 0xFE00;                    /* group B pins */
    *MCRC = 0x0000;                    /* group C pins */

/* Setup the core interrupts */
/* Note: this must be done before any peripheral interrupt is enabled */
    *IFR = 0x003F;                     /* clear any pending core interrupts */
    *IMR = 0x0004;                     /* enable desired core interrupts */

/* Setup the Event Manager: GP Timer 2 */
    *T2CON = 0x0000;                   /* disable timer */
    *T2CNT = 0x0000;                   /* clear timer counter */
    *T2PR = LED_prd;                   /* set timer period */
    *GPTCONA = 0x0000;                 /* configure GPTCON reg */
    *T2CON = 0xD740;                   /* enable timer, x/128 prescaler */

/* Setup the event manager interrupts */
    *EVAIFRA = 0xFFFF;                  /* clear all EVA group A interrupts */
    *EVAIFRB = 0xFFFF;                  /* clear all EVA group B interrupts */
    *EVAIFRC = 0xFFFF;                  /* clear all EVA group C interrupts */
    *EVAIMRA = 0x0000;                  /* enable desired EVA group A interrupts */
    *EVAIMRB = 0x0001;                  /* enable desired EVA group B interrupts */
    *EVAIMRC = 0x0000;                  /* enable desired EVA group C interrupts */

    *EVBIFRA = 0xFFFF;                  /* clear all EVB group A interrupts */
    *EVBIFRB = 0xFFFF;                  /* clear all EVB group B interrupts */
    *EVBIFRC = 0xFFFF;                  /* clear all EVB group C interrupts */
    *EVBIMRA = 0x0000;                  /* enable desired EVB group A interrupts */
    *EVBIMRB = 0x0000;                  /* enable desired EVB group B interrupts */
    *EVBIMRC = 0x0000;                  /* enable desired EVB group C interrupts */

/* Other setup */
    LED_index = 0x0001;                /* initialize the LED index */

/* Enable global interrupts */
    asm(" CLRC INTM");                 /* enable global interrupts */

/* Proceed with main routine */
    while(1);                          /* endless loop, wait for interrupt */

}                                      /* end of main() */


/********************** INTERRUPT SERVICE ROUTINES *********************/
interrupt void gisr3()
{
     *EVAIFRB = *EVAIFRB & 0x0001;     /* clear T2PINT flag */
     LED = LED_index;                  /* light the LEDs */
     LED_index = LED_index << 1;       /* left shift LED index */

     if(LED_index == 0x0010) LED_index = 0x0001;    /* reset LED index */
}

/**********************************************************************
* File: Adc_6_7_8.c -- File for Labs 6, 7 and 8 (not used in Lab 5)
* Devices: TMS320F2833x
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   07/15/08 - original
**********************************************************************/

#include "Lab.h"						// Main include file


/**********************************************************************
* Function: InitAdc()
*
* Description: Initializes the ADC on the F2833x
**********************************************************************/
void InitAdc(void)
{
//--- Reset the ADC module
	AdcRegs.ADCTRL1.bit.RESET = 1;		// Reset the ADC

// Must wait 2 ADCCLK periods for the reset to take effect.  The ADC is 
// already reset after a DSP reset, but this example is just showing good
// coding practice to reset the peripheral before configuring it (as you
// never know why the DSP has started the code over again from the
// beginning).  Assuming a 12.5 MHz ADCCLK was previously configured, and
// a 150 MHz SYSCLKOUT, the wait period of 2 ADCCLK periods equates to 24
// CPU clocks.  This is the example being used below.
 
	asm(" RPT #22 || NOP");				// Must wait for ADC reset to take effect

//--- Call the ADC_cal() function located in the Boot ROM.
//    ADC_cal_func_ptr is a macro defined in the file example_nonBios.h or
//    example_BIOS.h (as may be the case for the example being used).  This
//    macro simply defines ADC_cal_func_ptr to be a function pointer to
//    the correct address in the boot ROM.
	(*ADC_cal_func_ptr)();

//--- Select the ADC reference
	AdcRegs.ADCREFSEL.bit.REF_SEL = 0;	// 0=internal, 1=external
	
//--- Power-up the ADC
	AdcRegs.ADCTRL3.all = 0x00EC;		// Power-up reference and main ADC
// bit 15-8      0's:    reserved
// bit 7-6       11:     ADCBGRFDN, reference power, 00=off, 11=on
// bit 5         1:      ADCPWDN, main ADC power, 0=off, 1=on
// bit 4-1       0110:   ADCCLKPS, clock prescaler, FCLK=HSPCLK/(2*ADCCLKPS)
// bit 0         0:      SMODE_SEL, 0=sequential sampling, 1=simultaneous sampling

	DelayUs(5000);						// Wait 5ms before using the ADC

//--- Configure the other ADC register
	AdcRegs.ADCMAXCONV.all = 0x????;
// bit 15-7      0's:    reserved
// bit 6-4       ???:    MAX_CONV2 value
// bit 3-0       ????:   MAX_CONV1 value (0 means 1 conversion)

// For CPU servicing of ADC, we are only doing 1 conversion in the
// sequence.  So, we only need to configure the first channel
// selection in the sequence.  All other channel selection fields
// are don't cares in this example.
	AdcRegs.ADCCHSELSEQ1.bit.CONV00 = ?;	// Convert Channel ?

	AdcRegs.ADCTRL1.all = 0x????;
// bit 15        0:      reserved
// bit 14        ?:      RESET
// bit 13-12     00:     SUSMOD, 00=ignore emulation suspend
// bit 11-8      ????:   ACQ_PS (Acquisition)
// bit 7         ?:      CPS (Core clock)
// bit 6         ?:      CONT_RUN
// bit 5         ?:      SEQ_OVRD
// bit 4         ?:      SEQ_CASC
// bit 3-0       0000:   reserved

	AdcRegs.ADCTRL2.all = 0x????;
// bit 15        ?:      ePWM_SOCB_SEQ
// bit 14        ?:      RST_SEQ1
// bit 13        ?:      SOC_SEQ1
// bit 12        0:      reserved
// bit 11        ?:      INT_ENA_SEQ1
// bit 10        ?:      INT_MOD_SEQ1
// bit 9         0:      reserved
// bit 8         1:      ePWM_SOCA_SEQ1, 1=SEQ1 start from ePWM_SOCA trigger
// bit 7         0:      EXT_SOC_SEQ1, 1=SEQ1 start from ADCSOC pin
// bit 6         ?:      RST_SEQ2
// bit 5         ?:      SOC_SEQ2
// bit 4         0:      reserved
// bit 3         ?:      INT_ENA_SEQ2
// bit 2         ?:      INT_MOD_SEQ2
// bit 1         0:      reserved
// bit 0         ?:      ePWM_SOCB_SEQ2


//--- Enable the ADC interrupt
	                                  	// Enable ADCINT in PIE group 1
	              						// Enable INT1 in IER to enable PIE group

} // end InitAdc()


//--- end of file -----------------------------------------------------

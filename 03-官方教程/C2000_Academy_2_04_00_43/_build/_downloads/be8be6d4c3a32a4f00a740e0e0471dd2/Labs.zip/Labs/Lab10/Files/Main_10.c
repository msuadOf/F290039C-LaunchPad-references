/**********************************************************************
* File: Main_10.c -- File for Lab 10
* Devices: TMS320F2803x
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   09/15/09 - original
**********************************************************************/

#include "Lab.h"						// Main include file

//--- Global Variables
Uint16 DEBUG_TOGGLE = 1;					// Used for realtime mode investigation test
Uint16 DEBUG_FILTER = 1;				// Used to turn filter on/off
Uint16 AdcBuf[ADC_BUF_LEN];					// ADC buffer allocation
Uint16 AdcBufFiltered[ADC_BUF_LEN];		// ADC filtered data buffer allocation
_iq AdcBufIQ[ADC_BUF_LEN];				// ADC data buffer allocation - IQ
_iq AdcBufFilteredIQ[ADC_BUF_LEN];		// ADC filtered data buffer allocation - IQ
Uint32 PwmDuty;								// measured PWM duty cycle
Uint32 PwmPeriod;							// measured PWM period
Uint16 ClaFilteredOutput;				// Output of CLA filter
long	GlobalQ = GLOBAL_Q;				// IQmath debug support

_iq xDelayIQ[FILTER_LEN] = {0,0,0,0,0};	// filter delay chain
_iq coeffsIQ[FILTER_LEN] = {_IQ(0.0625),_IQ(0.25),_IQ(0.375),_IQ(0.25),_IQ(0.0625)};	// filter coefficients

float32 xDelay[FILTER_LEN] = {0,0,0,0,0};	// filter delay chain
float32 coeffs[FILTER_LEN] = {0.0625, 0.25, 0.375, 0.25, 0.0625};	// filter coefficients

#pragma DATA_SECTION(xDelay, "ClaToCpuMsgRAM");
#pragma DATA_SECTION(ClaFilteredOutput, "ClaToCpuMsgRAM");
#pragma DATA_SECTION(coeffs, "CpuToClaMsgRAM");


/**********************************************************************
* Function: main()
*
* Description: Main function for C28x workshop labs
**********************************************************************/
void main(void)
{
//--- CPU Initialization
	InitSysCtrl();						// Initialize the CPU (FILE: SysCtrl.c)
	InitGpio();							// Initialize the shared GPIO pins (FILE: Gpio.c)
	InitPieCtrl();						// Initialize and enable the PIE (FILE: PieCtrl.c)
	InitWatchdog();						// Initialize the Watchdog Timer (FILE: WatchDog.c)

//--- Copy all Flash sections that need to run from RAM (use memcpy() from RTS library)

// Section secureRamFuncs contains user defined code that runs from CSM secured RAM
	memcpy(&secureRamFuncs_runstart, &secureRamFuncs_loadstart, (Uint32)&secureRamFuncs_loadsize);

//--- Initialize the Flash and OTP
	            						// Initialize the Flash

//--- Peripheral Initialization
	InitAdc();							// Initialize the ADC (FILE: Adc.c)
	InitEPwm();							// Initialize the EPwm (FILE: EPwm.c) 
	InitECap();							// Initialize the ECap (FILE: ECap.c) 
	InitCla();							// Initialize the Cla (FILE: Cla.c) 

//--- Enable global interrupts
	asm(" CLRC INTM, DBGM");			// Enable global interrupts and realtime debug

//--- Main Loop
	while(1)							// endless loop - wait for an interrupt
	{
		asm(" NOP");
	}


} //end of main()


/*** end of file *****************************************************/

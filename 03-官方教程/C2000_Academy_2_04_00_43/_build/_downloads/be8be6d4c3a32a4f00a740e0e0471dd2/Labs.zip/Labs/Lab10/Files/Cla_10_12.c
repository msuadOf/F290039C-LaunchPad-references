/**********************************************************************
* File: Cla_10_12.c -- File for Lab 10 and 12
* Devices: TMS320F2803x
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   09/15/09 - original
**********************************************************************/

#include "Lab.h"						// Main include file


/**********************************************************************
* Function: InitCla()
*
* Description: Initializes CLA for the F2803x
**********************************************************************/
void InitCla(void)
{
	asm(" EALLOW");						// Enable EALLOW protected register access

//--- Copy the CLA program code from its load address to the CLA program
//--- memory (using memcpy() from RTS library) and assign memory to CLA.
	memcpy(&cla1Funcs_runstart, &cla1Funcs_loadstart, (Uint32)&cla1Funcs_loadsize);

//--- Memory Configuration 
	Cla1Regs.MMEMCFG.bit.PROGE = 1;		// Configure as CLA program memory

//--- Initialize CLA task interrupt vectors (symbols used to calculate vector address) 
	Cla1Regs.MVECT1 = (Uint16)((Uint32)&Cla1Task1 - (Uint32)&Cla1Prog_Start);
	Cla1Regs.MVECT2 = (Uint16)((Uint32)&Cla1Task2 - (Uint32)&Cla1Prog_Start);
	Cla1Regs.MVECT3 = (Uint16)((Uint32)&Cla1Task3 - (Uint32)&Cla1Prog_Start);
	Cla1Regs.MVECT4 = (Uint16)((Uint32)&Cla1Task4 - (Uint32)&Cla1Prog_Start);
	Cla1Regs.MVECT5 = (Uint16)((Uint32)&Cla1Task5 - (Uint32)&Cla1Prog_Start);
	Cla1Regs.MVECT6 = (Uint16)((Uint32)&Cla1Task6 - (Uint32)&Cla1Prog_Start);
	Cla1Regs.MVECT7 = (Uint16)((Uint32)&Cla1Task7 - (Uint32)&Cla1Prog_Start);
	Cla1Regs.MVECT8 = (Uint16)((Uint32)&Cla1Task8 - (Uint32)&Cla1Prog_Start);

//--- Select Task interrupt sources
	Cla1Regs.MPISRCSEL1.bit.PERINT1SEL = 0;	// 0=ADCINT1    1=none    2=EPWM1INT
	Cla1Regs.MPISRCSEL1.bit.PERINT2SEL = 1;	// 0=ADCINT2    1=none    2=EPWM2INT
	Cla1Regs.MPISRCSEL1.bit.PERINT3SEL = 1;	// 0=ADCINT3    1=none    2=EPWM3INT
	Cla1Regs.MPISRCSEL1.bit.PERINT4SEL = 1;	// 0=ADCINT4    1=none    2=EPWM4INT
	Cla1Regs.MPISRCSEL1.bit.PERINT5SEL = 1;	// 0=ADCINT5    1=none    2=EPWM5INT
	Cla1Regs.MPISRCSEL1.bit.PERINT6SEL = 1;	// 0=ADCINT6    1=none    2=EPWM6INT
	Cla1Regs.MPISRCSEL1.bit.PERINT7SEL = 1;	// 0=ADCINT7    1=none    2=EPWM7INT
	Cla1Regs.MPISRCSEL1.bit.PERINT8SEL = 1;	// 0=ADCINT8    1=none    2=CPU Timer 0

//--- Enable use software to start a task (IACK)
	Cla1Regs.MCTL.bit.IACKE = 1;			// Enable IACKE to start task using software

//--- Enable CLA task interruts
	Cla1Regs.MIER.all = 0x0001;			// Enable CLA interrupt 1

	asm(" EDIS");						// Disable EALLOW protected register access

//--- Enable the CLA interrupt
	PieCtrlRegs.PIEIER11.bit.INTx1 = 1;	// Enable CLA Task1 in PIE group #11
	IER |= 0x0400;						// Enable INT11 in IER to enable PIE group 11

} // end of InitCla()


//--- end of file -----------------------------------------------------

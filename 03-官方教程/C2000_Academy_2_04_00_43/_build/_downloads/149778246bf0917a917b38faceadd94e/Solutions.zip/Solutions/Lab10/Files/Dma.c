/**********************************************************************
* File: Dma.c -- Solution File for Lab 9, 10 and 12
* Devices: TMS320F2806x
* Author: Technical Training Organization (TTO), Texas Instruments
**********************************************************************/

#include "Lab.h"						// Main include file


/**********************************************************************
* Function: InitDma()
*
* Description: Initializes the DMA on the F2806x
**********************************************************************/
void InitDma(void)
{
	asm(" EALLOW");								// Enable EALLOW protected register access

//---------------------------------------------------------------------
//--- Overall DMA setup
//---------------------------------------------------------------------
	DmaRegs.DMACTRL.bit.HARDRESET = 1;			// Reset entire DMA module
	asm(" NOP");								// 1 cycle delay for HARDRESET to take effect

	DmaRegs.DEBUGCTRL.bit.FREE = 1;				// 1 = DMA unaffected by emulation halt
	DmaRegs.PRIORITYCTRL1.bit.CH1PRIORITY = 0;	// Not using CH1 Priority mode

//---------------------------------------------------------------------
//--- Configure DMA channel 1 to read the ADC results         
//---------------------------------------------------------------------
	DmaRegs.CH1.MODE.all = 0x8901;
// bit 15        1:      CHINTE, 0=interrupt disabled, 1=interrupt enabled
// bit 14        0:      DATASIZE, 0=16-bit, 1=32-bit
// bit 13-12     00:     reserved
// bit 11        1:      CONTINUOUS, 0=stop, 1=re-init after transfer complete
// bit 10        0:      ONESHOT, 0=one burst on trigger, 1=all bursts on trigger
// bit 9         0:      CHINTMODE, 0=start of transfer, 1=end of transfer
// bit 8         1:      PERINTE, peripheral interrupt trigger enable, 0=disabled, 1=enabled
// bit 7         0:      OVRINTE, overflow interrupt enable, 0=disabled, 1=enabled
// bit 6-5       00:     reserved
// bit 4-0       00001:  PERINTSEL, 1=ADCINT1

	DmaRegs.CH1.BURST_SIZE.bit.BURSTSIZE = 0;							// 0 means 1 word per burst
	DmaRegs.CH1.TRANSFER_SIZE = ADC_BUF_LEN-1;							// ADC_BUF_LEN bursts per transfer

	DmaRegs.CH1.SRC_TRANSFER_STEP = 0;									// 0 means add 0 to pointer each burst in a transfer
	DmaRegs.CH1.SRC_ADDR_SHADOW = (Uint32)&AdcResult.ADCRESULT0;		// SRC start address

	DmaRegs.CH1.DST_TRANSFER_STEP = 1;									// 1 = add 1 to pointer each burst in a transfer
	DmaRegs.CH1.DST_ADDR_SHADOW = (Uint32)AdcBufRaw;					// DST start address

	DmaRegs.CH1.CONTROL.all = 0x0091;
// bit 15        0:      reserved
// bit 14        0:      OVRFLG, overflow flag, read-only
// bit 13        0:      RUNSTS, run status, read-only
// bit 12        0;      BURSTSTS, burst status, read-only
// bit 11        0:      TRANSFERSTS, transfer status, read-only
// bit 10-9      00:     reserved
// bit 8         0:      PERINTFLG, read-only
// bit 7         1:      ERRCLR, error clear, 0=no action, 1=clear SYNCERR bit
// bit 6-5       00:     reserved
// bit 4         1:      PERINTCLR, periph event clear, 0=no action, 1=clear periph event
// bit 3         0:      PERINTFRC, periph event force, 0=no action, 1=force periph event
// bit 2         0:      SOFTRESET, 0=no action, 1=soft reset the channel
// bit 1         0:      HALT, 0=no action, 1=halt the channel
// bit 0         1:      RUN, 0=no action, 1=enable the channel

//--- Finish up
	asm(" EDIS");						// Disable EALLOW protected register access

//--- Enable the DMA interrupt
	PieCtrlRegs.PIEIER7.bit.INTx1 = 1;	// Enable DINTCH1 in PIE group 7
	IER |= 0x0040;						// Enable INT7 in IER to enable PIE group

} // end InitDma()


//*** end of file *****************************************************

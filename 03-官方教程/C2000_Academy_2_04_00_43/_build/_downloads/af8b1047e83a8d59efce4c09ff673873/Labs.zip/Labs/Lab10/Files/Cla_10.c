/**********************************************************************
* File: Cla_10.c -- File for Lab 10
* Devices: TMS320F2806x
* Author: Technical Training Organization (TTO), Texas Instruments
**********************************************************************/

#include "Lab.h"                        // Main include file


/**********************************************************************
* Function: InitCla()
*
* Description: Initializes CLA for the F2806x
**********************************************************************/
void InitCla(void)
{
    asm(" EALLOW");                     // Enable EALLOW protected register access

//--- Memory Configuration 
    Cla1Regs.MMEMCFG.bit.PROGE = ?;     // Configure as CLA program memory
    Cla1Regs.MMEMCFG.bit.RAM1E = ?;     // Configure as CLA data memory (C compiler scratchpad)

//--- Initialize CLA task interrupt vectors (symbols used to calculate vector address) 
    Cla1Regs.MVECT1 = (Uint16)((Uint32)&Cla1Task1 - (Uint32)&Cla1Prog_Start);
    Cla1Regs.MVECT2 = (Uint16)((Uint32)&Cla1Task2 - (Uint32)&Cla1Prog_Start);
    Cla1Regs.MVECT3 = (Uint16)((Uint32)&Cla1Task3 - (Uint32)&Cla1Prog_Start);
    Cla1Regs.MVECT4 = (Uint16)((Uint32)&Cla1Task4 - (Uint32)&Cla1Prog_Start);
    Cla1Regs.MVECT5 = (Uint16)((Uint32)&Cla1Task5 - (Uint32)&Cla1Prog_Start);
    Cla1Regs.MVECT6 = (Uint16)((Uint32)&Cla1Task6 - (Uint32)&Cla1Prog_Start);
    Cla1Regs.MVECT7 = (Uint16)((Uint32)&Cla1Task7 - (Uint32)&Cla1Prog_Start);
    Cla1Regs.MVECT8 = (Uint16)((Uint32)&Cla1Task8 - (Uint32)&Cla1Prog_Start);

//--- Select Task interrupt sources
    Cla1Regs.MPISRCSEL1.bit.PERINT1SEL = ?;	// 0=ADCINT1    1=none    2=EPWM1INT
    Cla1Regs.MPISRCSEL1.bit.PERINT2SEL = ?;	// 0=ADCINT2    1=none    2=EPWM2INT
    Cla1Regs.MPISRCSEL1.bit.PERINT3SEL = ?;	// 0=ADCINT3    1=none    2=EPWM3INT
    Cla1Regs.MPISRCSEL1.bit.PERINT4SEL = ?;	// 0=ADCINT4    1=none    2=EPWM4INT
    Cla1Regs.MPISRCSEL1.bit.PERINT5SEL = ?;	// 0=ADCINT5    1=none    2=EPWM5INT
    Cla1Regs.MPISRCSEL1.bit.PERINT6SEL = ?;	// 0=ADCINT6    1=none    2=EPWM6INT
    Cla1Regs.MPISRCSEL1.bit.PERINT7SEL = ?;	// 0=ADCINT7    1=none    2=EPWM7INT
    Cla1Regs.MPISRCSEL1.bit.PERINT8SEL = ?;	// 0=ADCINT8    1=none    2=CPU Timer 0

//--- Enable use software to start a task (IACK)
    Cla1Regs.MCTL.bit.IACKE = ?;        // Enable IACKE to start task using software

//--- Force one-time initialization Task 8 - zero delay buffer
    Cla1Regs.MIER.all = 0x????;            // Enable CLA interrupt 8
    asm("  IACK  #0x0080");                // IACK - CLA task force instruction
    asm("  RPT #3 || NOP");                // Wait at least 4 cycles
    while(Cla1Regs.MIRUN.bit.INT8 == 1);   // Loop until task completes

//--- Enable CLA task interrupts
    Cla1Regs.MIER.all = 0x????;        // Enable CLA interrupt 1 (and disable interrupt 8)

    asm(" EDIS");                      // Disable EALLOW protected register access

//--- Enable the CLA interrupt
                                           // Enable CLA Task1 in PIE group #11
                                           // Enable INT11 in IER to enable PIE group 11

} // end of InitCla()


//--- end of file -----------------------------------------------------

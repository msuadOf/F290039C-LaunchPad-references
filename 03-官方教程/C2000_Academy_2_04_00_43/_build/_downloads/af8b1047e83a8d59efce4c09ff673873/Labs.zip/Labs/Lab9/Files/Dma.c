/**********************************************************************
* File: Dma.c -- File for Lab 9, 10 and 12
* Devices: TMS320F2806x
* Author: Technical Training Organization (TTO), Texas Instruments
**********************************************************************/

#include "Lab.h"						// Main include file


/**********************************************************************
* Function: InitDma()
*
* Description: Initializes the DMA on the F2806x
**********************************************************************/
void InitDma(void)
{
	asm(" EALLOW");								// Enable EALLOW protected register access

//---------------------------------------------------------------------
//--- Overall DMA setup
//---------------------------------------------------------------------
	DmaRegs.DMACTRL.bit.HARDRESET = 1;			// Reset entire DMA module
	asm(" NOP");								// 1 cycle delay for HARDRESET to take effect

	DmaRegs.DEBUGCTRL.bit.FREE = 1;				// 1 = DMA unaffected by emulation halt
	DmaRegs.PRIORITYCTRL1.bit.CH1PRIORITY = 0;	// Not using CH1 Priority mode

//---------------------------------------------------------------------
//--- Configure DMA channel 1 to read the ADC results         
//---------------------------------------------------------------------
	DmaRegs.CH1.MODE.all = 0x????;
// bit 15        ?:      CHINTE
// bit 14        ?:      DATASIZE
// bit 13-12     00:     reserved
// bit 11        ?:      CONTINUOUS
// bit 10        ?:      ONESHOT
// bit 9         ?:      CHINTMODE
// bit 8         ?:      PERINTE
// bit 7         ?:      OVRINTE
// bit 6-5       00:     reserved
// bit 4-0       ?????:  PERINTSEL

	DmaRegs.CH1.BURST_SIZE.bit.BURSTSIZE = 0;							// 0 means 1 word per burst
	DmaRegs.CH1.TRANSFER_SIZE = ADC_BUF_LEN-1;							// ADC_BUF_LEN bursts per transfer

	DmaRegs.CH1.SRC_TRANSFER_STEP = 0;									// 0 means add 0 to pointer each burst in a transfer
	DmaRegs.CH1.SRC_ADDR_SHADOW = (Uint32)&AdcResult.ADCRESULT0;		// SRC start address

	DmaRegs.CH1.DST_TRANSFER_STEP = 1;									// 1 = add 1 to pointer each burst in a transfer
	DmaRegs.CH1.DST_ADDR_SHADOW = (Uint32)AdcBufRaw;					// DST start address

	DmaRegs.CH1.CONTROL.all = 0x????;
// bit 15        0:      reserved
// bit 14        ?:      OVRFLG
// bit 13        ?:      RUNSTS
// bit 12        ?:      BURSTSTS
// bit 11        ?:      TRANSFERSTS
// bit 10-9      00:     reserved
// bit 8         ?:      PERINTFLG
// bit 7         ?:      ERRCLR
// bit 6-5       00:     reserved
// bit 4         ?:      PERINTCLR
// bit 3         ?:      PERINTFRC
// bit 2         ?:      SOFTRESET
// bit 1         ?:      HALT
// bit 0         ?:      RUN

//--- Finish up
	asm(" EDIS");						// Disable EALLOW protected register access

//--- Enable the DMA interrupt
	                                  	// Enable DINTCH1 in PIE group 7
	              						// Enable INT7 in IER to enable PIE group

} // end InitDma()


//*** end of file *****************************************************

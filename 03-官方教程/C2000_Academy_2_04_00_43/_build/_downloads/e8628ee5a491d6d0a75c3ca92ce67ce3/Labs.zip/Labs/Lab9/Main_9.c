/**********************************************************************
* File: Main_9.c -- File for Lab 9
* Devices: TMS320F2808, TMS320F2806, TMS320F2801
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   09/26/05 - original (based on DSP280x header files v1.20)
**********************************************************************/

#include "DSP280x_Device.h"				// Peripheral address definitions
#include "lab.h"

/*** Global variables used by AdcSwi() ***/







/**********************************************************************
* Function: main()
*
* Description: Main function for C28x workshop labs
**********************************************************************/
void main(void)
{
/*** Initialization ***/
	InitSysCtrl();						// Initialize the CPU (FILE: SysCtrl.c)
	InitGpio();							// Initialize the shared GPIO pins (FILE: Gpio.c)
	InitPieCtrl();						// Enable the PIE (FILE: PieCtrl.c)
	InitAdc();							// Initialize the ADC (FILE: Adc.c)
	InitEPwm();							// Initialize the EPwm (FILE: EPwm.c) 
	InitECap();							// Initialize the ECap (FILE: ECap.c) 

/*** Enable the Watchdog interrupt ***/
	PieCtrlRegs.PIEIER1.bit.INTx8 = 1;	// Enable WAKEINT (LPM/WD) in PIE group #1
	IER |= 0x0001;						// Enable INT1 in IER to enable PIE group 1

/*** Enable global interrupts ***/
	asm(" CLRC INTM");					// Enable global interrupts

/*** Main Loop ***/
	while(1)							// endless loop - wait for an interrupt
	{
		asm(" NOP");
	}


} //end of main()


/**********************************************************************
* Function: AdcSwi()
*
* Description: ADC interrupt SWI
**********************************************************************/
void AdcSwi(void)
{







} //end of AdcSwi()


/**********************************************************************
* Function: LedBlink()
*
* Description: Blinks LED on eZdsp F2808 board
**********************************************************************/
void LedBlink(void)
{


	
} //end of LedBlink()


/*** end of file *****************************************************/

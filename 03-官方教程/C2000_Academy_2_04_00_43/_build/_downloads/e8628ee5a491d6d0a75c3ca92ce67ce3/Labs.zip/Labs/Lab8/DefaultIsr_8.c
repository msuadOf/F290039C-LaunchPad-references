/**********************************************************************
* File: DefaultIsr_8.c -- File for Lab 8
* Devices: TMS320F2808, TMS320F2806, TMS320F2801
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   09/26/05 - original (based on DSP280x header files v1.20)
**********************************************************************/

#include "DSP280x_Device.h"
#include "lab.h"


/*** Global variables used by ADC_ISR() ***/
Uint16 DEBUG_TOGGLE = 1;					// Used in realtime mode investigation - Lab 6

#define AdcFsVoltage	_IQ(3.0)		// ADC full scale voltage
#define AdcBufLen		50				// ADC results buffer length
_iq AdcBuf[AdcBufLen];					// ADC results buffer
_iq AdcBufFiltered[AdcBufLen];			// filtered ADC results buffer

#define N	5							// filter length
_iq xDelay[N] = {0, 0, 0, 0, 0};		// filter delay chain

// filter coefficients
_iq coeffs[N] = {_IQ(0.0625), _IQ(0.25), _IQ(0.375), _IQ(0.25), _IQ(0.0625)};


/*** Global variables used by ECAP1_INT_ISR() (Lab 7) ***/
Uint32 PWM_duty;							// measured PWM duty cycle
Uint32 PWM_period;							// measured PWM period



/*********************************************************************/
interrupt void ADCINT_ISR(void)		// 0x000D4A  ADCINT (ADC)
{
static volatile Uint16 GPIO34_count = 0;		// Counter for pin toggle
static Uint16 ibuf=0;                                   // index into ADC buffers

	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;		// Must acknowledge the PIE group

/*** Manage the ADC registers ***/
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;			// Reset SEQ1 to CONV00 state
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;			// Clear ADC SEQ1 interrupt flag

/*** Read the ADC result:
	1) typecast the unsigned 16-bit result to 32-bit IQ16
	2) convert from IQ16 to IQ format
	3) scale by ADC full-scale range
***/
	AdcBuf[ibuf] = _IQmpy(AdcFsVoltage, _IQ16toIQ( (_iq)AdcRegs.ADCRESULT0));

/*** Call the filter function ***/
	xDelay[0] = AdcBuf[ibuf];					// Add the new entry to the delay chain
	AdcBufFiltered[ibuf] = IQssfir(xDelay, coeffs, N);

/*** Brute-force the circular buffer ***/
	ibuf++;									// Increment the index
	if(ibuf == AdcBufLen) ibuf = 0;			// Rewind the pointer to beginning


/*** Example: Toggle GPIO33 so we can read it with the ADC ***/
	if(DEBUG_TOGGLE == 1)
	{
		GpioDataRegs.GPBTOGGLE.bit.GPIO33 = 1;		// Toggle the pin
	}
	
/*** Example: Toggle GPIO34, which is connected to the LED on the eZdsp board ***/
	if(GPIO34_count++ > 25000)					// Toggle slowly to see the LED blink
	{
		GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;	// Toggle the pin
		GPIO34_count = 0;						// Reset the counter
	}

} // end ADCINT_ISR()



/*********************************************************************/
interrupt void WAKEINT_ISR(void)		// 0x000D4E  WAKEINT (LPM/WD)
{
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;	// Must acknowledge the PIE group
  
// Next two lines for debug only - remove after inserting your ISR
	asm (" ESTOP0");					// Emulator Halt instruction
	while(1);
}



/*********************************************************************/
interrupt void ECAP1_INT_ISR(void)			// 0x000D70  ECAP1_INT (ECAP1)
{
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;	// Must acknowledge the PIE group
	ECap1Regs.ECCLR.bit.INT = 1;			// Clear the ECAP1 interrupt flag
	ECap1Regs.ECCLR.bit.CEVT3 = 1;			// Clear the CEVT3 flag

// Compute the PWM duty period (rising edge to falling edge)
	PWM_duty = (int32)ECap1Regs.CAP2 - (int32)ECap1Regs.CAP1;

// Compute the PWM period (rising edge to rising edge)
	PWM_period = (int32)ECap1Regs.CAP3 - (int32)ECap1Regs.CAP1;
}



/*** end of file *****************************************************/

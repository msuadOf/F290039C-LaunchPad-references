/**********************************************************************
* File: Flash.c -- File for Lab 10
* Devices: TMS320F2812, TMS320F2811, TMS320F2810
* Author: Technical Training Organization (TTO), Texas Instruments Inc.
* History:
*   11/10/03 - original (based on DSP281x header files v1.00)
**********************************************************************/

#include "DSP281x_Device.h"
#include "lab.h"


/**********************************************************************
* Function: InitFlash()
* Description: Initializes the F281x flash timing registers.
* Notes:
*  1) This function MUST be executed out of RAM.  Executing it out of
*     OTP/FLASH will produce unpredictable results.
*  2) The flash registers are code security module protected.  Therefore,
*     you must either run this function from L0/L1 RAM, or you must
*     first unlock the CSM.  Note that unlocking the CSM as part of
*     the program flow can compromise the code security.
*  3) Final flash characterization needs to be performed by TI.  The
*     below settings may not meet final specifications, and are for
*     example purposes only.  Check the latest device datasheet for 
*     TMS qualified specifications.
**********************************************************************/
#pragma CODE_SECTION(InitFlash, "secureRamFuncs")
void InitFlash(void)
{
	asm(" EALLOW");									// Enable EALLOW protected register access
	FlashRegs.FPWR.bit.PWR = 3;						// Pump and bank set to active mode
	FlashRegs.FSTATUS.bit.V3STAT = 1;				// Clear the 3VSTAT bit
	FlashRegs.FSTDBYWAIT.bit.STDBYWAIT = 0x01FF;	// Sleep to standby transition cycles
	FlashRegs.FACTIVEWAIT.bit.ACTIVEWAIT = 0x01FF;	// Standby to active transition cycles
	FlashRegs.FBANKWAIT.bit.RANDWAIT = 5;			// Random access waitstates
	FlashRegs.FBANKWAIT.bit.PAGEWAIT = 5;			// Paged access waitstates
	FlashRegs.FOTPWAIT.bit.OTPWAIT = 8;				// Random access waitstates
	FlashRegs.FOPT.bit.ENPIPE = 1;					// Enable the flash pipeline
	asm(" EDIS");									// Disable EALLOW protected register access

/*** Force a complete pipeline flush to ensure that the write to the last register
     configured occurs before returning.  Safest thing is to wait 8 full cycles. ***/

    asm(" RPT #6 || NOP");

} //end of InitFlash()

/*** end of file *****************************************************/

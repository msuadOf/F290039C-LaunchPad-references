/**********************************************************************
* File: Main_5.c -- File for Lab 5
* Devices: TMS320F2812, TMS320F2811, TMS320F2810
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   11/10/03 - original (based on DSP281x header files v1.00)
**********************************************************************/

#include "DSP281x_Device.h"				// Peripheral address definitions
#include "lab.h"

/**********************************************************************
* Function: main()
*
* Description: Main function for C28x workshop labs
**********************************************************************/
void main(void)
{
/*** Initialization ***/
	InitSysCtrl();						// Initialize the CPU (FILE: SysCtrl.c)
	InitGpio();							// Initialize the shared GPIO pins (FILE: Gpio.c)
	              						// Initialize and enable the PIE (FILE: PieCtrl.c)

/*** Enable the Watchdog interrupt ***/
	                                	// Enable WAKEINT (LPM/WD) in PIE group #1
	            						// Enable INT1 in IER to enable PIE group 1

/*** Enable global interrupts ***/
	                					// Enable global interrupts

/*** Main Loop ***/
	while(1)							// endless loop - wait for an interrupt
	{
		asm(" NOP");
	}


} //end of main()


/*** end of file *****************************************************/

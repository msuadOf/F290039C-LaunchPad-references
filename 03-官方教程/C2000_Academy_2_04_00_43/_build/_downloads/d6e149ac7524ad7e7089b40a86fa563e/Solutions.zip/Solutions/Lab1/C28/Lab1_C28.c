//###########################################################################
// FILE:   Lab1_C28.c
//###########################################################################
//

#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include <string.h>

extern Uint16 RamfuncsLoadStart;
extern Uint16 RamfuncsLoadSize;
extern Uint16 RamfuncsRunStart;

void main(void)
{
   unsigned long uldelay;
   InitSysCtrl();							// Init C28 core
   EALLOW;
   GpioG1CtrlRegs.GPCDIR.bit.GPIO70 = 1; 	// GPIO70 as output
   EDIS;
   GpioG1DataRegs.GPCDAT.bit.GPIO70 = 1;	// turn off LED
// Copy time critical code and Flash setup code to RAM
// This includes the following functions: InitFlash();
// The  RamfuncsLoadStart, RamfuncsLoadSize and RamfuncsRunStart
// symbols are created by the linker. Refer to the device .cmd file.
   memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize); 
   
// Call Flash Initialization to setup flash waitstates
// This function must reside in RAM
    InitFlash();       

    while(1)
    {
       GpioG1DataRegs.GPCDAT.bit.GPIO70 = 0;			// LD2 ON
       for(uldelay = 0; uldelay < 1000000; uldelay++); 	// delay
       GpioG1DataRegs.GPCDAT.bit.GPIO70 = 1;			// LD2 OFF
       for(uldelay = 0; uldelay < 1000000; uldelay++); 	// delay
    }
}





//###########################################################################
// FILE:   Lab3_C28.c
//###########################################################################
//

#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include <string.h>

#define C28_FREQ    150         //C28 CPU frequency in MHz

extern Uint16 RamfuncsLoadStart;
extern Uint16 RamfuncsLoadSize;
extern Uint16 RamfuncsRunStart;
interrupt void cpu_timer0_isr(void);

void main(void)
{
   InitSysCtrl();							// Init C28 core
   EALLOW;
   GpioG1CtrlRegs.GPCDIR.bit.GPIO70 = 1; 	// GPIO70 as output
   EDIS;
   GpioG1DataRegs.GPCDAT.bit.GPIO70 = 1;	// turn off LED
// Copy time critical code and Flash setup code to RAM
// This includes the following functions: InitFlash();
// The  RamfuncsLoadStart, RamfuncsLoadSize and RamfuncsRunStart
// symbols are created by the linker. Refer to the device .cmd file.
   memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize); 
   
// Call Flash Initialization to setup flash waitstates
// This function must reside in RAM
    InitFlash();       

	InitPieCtrl();
	InitPieVectTable();
	EALLOW; // This is needed to write to EALLOW protected registers
	PieVectTable.TINT0 = &cpu_timer0_isr;
	EDIS;
	InitCpuTimers();
	ConfigCpuTimer(&CpuTimer0, C28_FREQ, 125000);
	PieCtrlRegs.PIEIER1.bit.INTx7 = 1;
	IER |= 1;
	EINT;  // Enable Global interrupt INTM
	ERTM;  // Enable Global realtime interrupt DBGM

	CpuTimer0Regs.TCR.bit.TSS = 0;	// start T0
	while(1);
}

interrupt void cpu_timer0_isr(void)
{
    GpioG1DataRegs.GPCDAT.bit.GPIO70 ^= 1;	// Toggle LED
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;	// ACK PIE � Int
}





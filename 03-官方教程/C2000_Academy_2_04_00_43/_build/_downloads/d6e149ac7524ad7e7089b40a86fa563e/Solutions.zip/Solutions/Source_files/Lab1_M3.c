//###########################################################################
// FILE:   Lab1_M3.c
//###########################################################################
//

#include <string.h>

#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_gpio.h"
#include "inc/hw_types.h"
#include "inc/hw_sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/flash.h"
#include "driverlib/ipc.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

extern unsigned long RamfuncsLoadStart;
extern unsigned long RamfuncsRunStart;
extern unsigned long RamfuncsLoadSize;

//*****************************************************************************
// Blink LED LD3
//*****************************************************************************
void main(void)
{
    volatile unsigned long ulLoop;

    // Disable Protection
    HWREG(SYSCTL_MWRALLOW) =  0xA5A5A5A5;

    // Sets up PLL, M3 running at 75 MHz and C28 running at 150 MHz
    SysCtlClockConfigSet(SYSCTL_USE_PLL | (SYSCTL_SPLLIMULT_M & 0xF) |
                         SYSCTL_SYSDIV_1 | SYSCTL_M3SSDIV_2 |
                         SYSCTL_XCLKDIV_4);

// Copy time critical code and Flash setup code to RAM
// This includes the following functions:  InitFlash();
// The  RamfuncsLoadStart, RamfuncsLoadSize, and RamfuncsRunStart
// symbols are created by the linker. Refer to the device .cmd file.
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize);
    
// Call Flash Initialization to setup flash waitstates
// This function must reside in RAM
    FlashInit();                         
                      
    //  Send boot command to allow the C28 application to begin execution
    //  IPCMtoCBootControlSystem(CBROM_MTOC_BOOTMODE_BOOT_FROM_FLASH);

    // Enable clock supply for GPIOC
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    
    // Give C28 control of Port C pin 6
    // GPIOPinConfigureCoreSelect(GPIO_PORTC_BASE, 0x40, GPIO_PIN_C_CORE_SELECT);

    // Disable clock supply for the watchdog modules
    SysCtlPeripheralDisable(SYSCTL_PERIPH_WDOG1);
    SysCtlPeripheralDisable(SYSCTL_PERIPH_WDOG0);
    
    // Enable processor interrupts.
    IntMasterEnable();

    // Set up the Pin for LED LD3
    GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, GPIO_PIN_7);
    GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, ~0);
    
    while(1)
    {
        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, 0);	// LD3 ON
        for(ulLoop = 0; ulLoop < 2750000; ulLoop++); 	// delay
        GPIOPinWrite(GPIO_PORTC_BASE, GPIO_PIN_7, ~0);	// LD3 OFF
        for(ulLoop = 0; ulLoop < 2750000; ulLoop++);	// delay
    }
}




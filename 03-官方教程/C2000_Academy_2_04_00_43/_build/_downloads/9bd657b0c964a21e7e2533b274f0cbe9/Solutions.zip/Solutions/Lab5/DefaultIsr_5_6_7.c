/**********************************************************************
* File: DefaultIsr_5_6_7.c -- Solution File for Labs 5, 6, and 7
* Devices: TMS320F2808, TMS320F2806, TMS320F2801
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   09/26/05 - original (based on DSP280x header files v1.20)
**********************************************************************/

#include "DSP280x_Device.h"
#include "lab.h"


/*** Global variables used by ADC_ISR() (Labs 6 and 7) ***/
#define AdcBuf_len	50					// ADC buffer length
Uint16 AdcBuf[AdcBuf_len];			// ADC buffer allocation
Uint16 DEBUG_TOGGLE = 1;					// Used in realtime mode investigation - Lab 6

/*** Global variables used by ECAP1_INT_ISR() (Lab 7) ***/
Uint32 PWM_duty;							// measured PWM duty cycle
Uint32 PWM_period;							// measured PWM period


/*********************************************************************/
interrupt void ADCINT_ISR(void)		// 0x000D4A  ADCINT (ADC)
{
static volatile Uint16 GPIO34_count = 0;		// Counter for pin toggle
static Uint16 *AdcBuf_ptr = AdcBuf;			// Pointer to buffer

	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;		// Must acknowledge the PIE group

/*** Manage the ADC registers ***/
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;			// Reset SEQ1 to CONV00 state
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;			// Clear ADC SEQ1 interrupt flag

/*** Read the ADC result ***/
	*AdcBuf_ptr++ = AdcRegs.ADCRESULT0 >> 4;	// Read the result

/*** Brute-force the circular buffer ***/
	if( AdcBuf_ptr == (AdcBuf + AdcBuf_len) )
		AdcBuf_ptr = AdcBuf;					// Rewind the pointer to beginning

/*** Example: Toggle GPIO33 so we can read it with the ADC ***/
	if(DEBUG_TOGGLE == 1)
	{
		GpioDataRegs.GPBTOGGLE.bit.GPIO33 = 1;		// Toggle the pin
	}

/*** Example: Toggle GPIO34, which is connected to the LED on the eZdsp board ***/
	if(GPIO34_count++ > 25000)					// Toggle slowly to see the LED blink
	{
		GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;	// Toggle the pin
		GPIO34_count = 0;						// Reset the counter
	}

} // end ADCINT_ISR()



/*********************************************************************/
interrupt void WAKEINT_ISR(void)		// 0x000D4E  WAKEINT (LPM/WD)
{
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;	// Must acknowledge the PIE group
  
// Next two lines for debug only - remove after inserting your ISR
	asm (" ESTOP0");					// Emulator Halt instruction
	while(1);
}



/*********************************************************************/
interrupt void ECAP1_INT_ISR(void)			// 0x000D70  ECAP1_INT (ECAP1)
{
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP4;	// Must acknowledge the PIE group
	ECap1Regs.ECCLR.bit.INT = 1;			// Clear the ECAP1 interrupt flag
	ECap1Regs.ECCLR.bit.CEVT3 = 1;			// Clear the CEVT3 flag

// Compute the PWM duty period (rising edge to falling edge)
	PWM_duty = (int32)ECap1Regs.CAP2 - (int32)ECap1Regs.CAP1;

// Compute the PWM period (rising edge to rising edge)
	PWM_period = (int32)ECap1Regs.CAP3 - (int32)ECap1Regs.CAP1;
}



/*** end of file *****************************************************/

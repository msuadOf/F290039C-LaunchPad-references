/**********************************************************************
* File: lab.h
* Device: TMS320F2808, TMS320F2806, TMS320F2801
* Author: Technical Training Organization (TTO), Texas Instruments
* Description: Include file for C28x workshop labs.  Include this
*   file in all C-source files.
* History:
*   09/26/05 - original (based on DSP280x header files v1.20)
**********************************************************************/

#ifndef EXAMPLE_H
#define EXAMPLE_H

//---------------------------------------------------------------------------
// Include Standard C Language Header Files
//
#include <string.h>


//---------------------------------------------------------------------------
// Include DSP/BIOS Header Files
//
#include "labcfg.h"


//---------------------------------------------------------------------------
// Include any other Header Files
//
#include "IQmathLib.h"                         /* used in Labs 8, 9, and 10 */


//---------------------------------------------------------------------------
// Function Prototypes
//
extern void DelayUs(Uint16);
extern void SetDBGIER(Uint16);
extern void InitSysCtrl(void);
extern void InitXintf(void);
extern void InitPieCtrl(void);
extern void InitGpio(void);
extern void InitFlash(void);
extern void InitAdc(void);
extern void InitEv(void);
extern  _iq IQssfir(_iq*, _iq*, Uint16);       /* used in Labs 8, 9, and 10 */

//---------------------------------------------------------------------------
// Global symbols defined in the linker command file
//
extern Uint16 hwi_vec_loadstart;
extern Uint16 hwi_vec_loadend;
extern Uint16 hwi_vec_runstart;
extern Uint16 secureRamFuncs_loadstart;
extern Uint16 secureRamFuncs_loadend;
extern Uint16 secureRamFuncs_runstart;
extern Uint16 trcdata_loadstart;
extern Uint16 trcdata_loadend;
extern Uint16 trcdata_runstart;


//---------------------------------------------------------------------------
// Global symbols defined in source files
//



//---------------------------------------------------------------------------
#endif  // end of EXAMPLE_H definition

/*** end of file *****************************************************/

/**********************************************************************
* File: Main_9.c -- Solution File for Lab 9
* Devices: TMS320F2812, TMS320F2811, TMS320F2810
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   11/10/03 - original (based on DSP281x header files v1.00)
**********************************************************************/

#include "DSP281x_Device.h"				// Peripheral address definitions
#include "lab.h"

/*** Global variables used by AdcSwi() ***/
#define AdcFsVoltage	_IQ(3.0)		// ADC full scale voltage
#define AdcBufLen		50				// ADC results buffer length
_iq AdcBuf[AdcBufLen];					// ADC results buffer
_iq AdcBufFiltered[AdcBufLen];			// filtered ADC results buffer

#define N	5							// filter length
_iq xDelay[N] = {0, 0, 0, 0, 0};		// filter delay chain

// filter coefficients
_iq coeffs[N] = {_IQ(0.0625), _IQ(0.25), _IQ(0.375), _IQ(0.25), _IQ(0.0625)};


/**********************************************************************
* Function: main()
*
* Description: Main function for C28x workshop labs
**********************************************************************/
void main(void)
{
/*** Initialization ***/
	InitSysCtrl();						// Initialize the CPU (FILE: SysCtrl.c)
	InitGpio();							// Initialize the shared GPIO pins (FILE: Gpio.c)
	InitPieCtrl();						// Enable the PIE (FILE: PieCtrl.c)
	InitAdc();							// Initialize the ADC (FILE: Adc.c)
	InitEv();							// Initialize the Event Manager (FILE: Ev.c) 

/*** Enable the Watchdog interrupt ***/
	PieCtrlRegs.PIEIER1.bit.INTx8 = 1;	// Enable WAKEINT (LPM/WD) in PIE group #1
	IER |= 0x0001;						// Enable INT1 in IER to enable PIE group 1

/*** Enable global interrupts ***/
									// DSP/BIOS will enable global interrupts

/*** Main Loop ***/
									// while() loop removed to enable DSP/BIOS


} //end of main()


/**********************************************************************
* Function: AdcSwi()
*
* Description: ADC interrupt SWI
**********************************************************************/
void AdcSwi(void)
{
static Uint16 ibuf=0;                           // index into ADC buffers
static Uint32 AdcSwi_count=0;					// used for LOG_printf

/*** Using LOG_printf() to write to a log buffer ***/
	LOG_printf(&trace, "AdcSwi_count = %u", AdcSwi_count++);

/*** Manage the ADC registers ***/
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;			// Reset SEQ1 to CONV00 state
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;			// Clear ADC SEQ1 interrupt flag

/*** Read the ADC result:
	1) typecast the unsigned 16-bit result to 32-bit IQ16
	2) convert from IQ16 to IQ format
	3) scale by ADC full-scale range
***/
	AdcBuf[ibuf] = _IQmpy(AdcFsVoltage, _IQ16toIQ( (_iq)AdcRegs.ADCRESULT0));

/*** Call the filter function ***/
	xDelay[0] = AdcBuf[ibuf];					// Add the new entry to the delay chain
	AdcBufFiltered[ibuf] = IQssfir(xDelay, coeffs, N);

/*** Brute-force the circular buffer ***/
	ibuf++;									// Increment the index
	if(ibuf == AdcBufLen) ibuf = 0;			// Rewind the pointer to beginning

} //end of AdcSwi()


/**********************************************************************
* Function: LedBlink()
*
* Description: Blinks LED on eZdsp F2812 board
**********************************************************************/
void LedBlink(void)
{

	GpioDataRegs.GPFTOGGLE.bit.GPIOF14 = 1;	// Toggle the pin
	
} //end of LedBlink()


/*** end of file *****************************************************/

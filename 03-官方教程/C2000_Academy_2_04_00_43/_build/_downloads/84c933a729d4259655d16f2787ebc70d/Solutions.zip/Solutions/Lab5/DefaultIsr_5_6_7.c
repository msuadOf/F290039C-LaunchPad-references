/**********************************************************************
* File: DefaultIsr_5_6_7.c -- Solution File for Labs 5, 6, and 7
* Devices: TMS320F2812, TMS320F2811, TMS320F2810
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   11/10/03 - original (based on DSP281x header files v1.00)
**********************************************************************/

#include "DSP281x_Device.h"
#include "lab.h"


/*** Global variables used by ADC_ISR() (Labs 6 and 7) ***/
#define AdcBuf_len	50					// ADC buffer length
Uint16 AdcBuf[AdcBuf_len];			// ADC buffer allocation
Uint16 DEBUG_TOGGLE = 1;					// Used in realtime mode investigation - Lab 6

/*** Global variables used by CAPINT1_ISR() (Lab 7) ***/
Uint16 CAP_rising = 0;					// Captured rising edge timestamp
Uint16 CAP_falling = 0;					// Captured falling edge timestamp
Uint16 CAP_duty = 0;					// PWM duty cycle computed using captures



/*********************************************************************/
interrupt void ADCINT_ISR(void)		// 0x000D4A  ADCINT (ADC)
{
static volatile Uint16 GPIOF14_count = 0;		// Counter for pin toggle
static Uint16 *AdcBuf_ptr = AdcBuf;			// Pointer to buffer

	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;		// Must acknowledge the PIE group

/*** Manage the ADC registers ***/
	AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;			// Reset SEQ1 to CONV00 state
	AdcRegs.ADCST.bit.INT_SEQ1_CLR = 1;			// Clear ADC SEQ1 interrupt flag

/*** Read the ADC result ***/
	*AdcBuf_ptr++ = AdcRegs.ADCRESULT0 >> 4;	// Read the result

/*** Brute-force the circular buffer ***/
	if( AdcBuf_ptr == (AdcBuf + AdcBuf_len) )
		AdcBuf_ptr = AdcBuf;					// Rewind the pointer to beginning

/*** Example: Toggle GPIOA1 so we can read it with the ADC ***/
	if(DEBUG_TOGGLE == 1)
	{
		GpioDataRegs.GPATOGGLE.bit.GPIOA1 = 1;		// Toggle the pin
	}

/*** Example: Toggle GPIOF14, which is connected to the LED on the eZdsp board ***/
	if(GPIOF14_count++ > 20000)					// Toggle slowly to see the LED blink
	{
		GpioDataRegs.GPFTOGGLE.bit.GPIOF14 = 1;	// Toggle the pin
		GPIOF14_count = 0;						// Reset the counter
	}

} // end ADCINT_ISR()



/*********************************************************************/
interrupt void WAKEINT_ISR(void)		// 0x000D4E  WAKEINT (LPM/WD)
{
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;	// Must acknowledge the PIE group
  
// Next two lines for debug only - remove after inserting your ISR
	asm (" ESTOP0");					// Emulator Halt instruction
	while(1);
}



/*********************************************************************/
interrupt void CAPINT1_ISR(void)		// 0x000D68  CAPINT1 (EV-A)
{
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;	// Must acknowledge the PIE group

/*** Manage the CAP1 registers ***/
	EvaRegs.EVAIFRC.bit.CAP1INT = 1;		// Clear the CAP1INT flag

/*** Read the CAP1FIFO ***/
	CAP_rising = EvaRegs.CAP1FIFO;			// Read the top entry
	CAP_falling = EvaRegs.CAP1FIFO;			// Read the 2nd entry

/*** Compute the duty cycle using signed math ***/
	CAP_duty = (Uint16)( (int16)CAP_falling - (int16)CAP_rising );

}



/*** end of file *****************************************************/

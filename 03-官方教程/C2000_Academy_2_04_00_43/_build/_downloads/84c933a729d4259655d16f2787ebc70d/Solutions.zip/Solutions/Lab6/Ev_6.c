/**********************************************************************
* File: Ev_6.c -- Solution File Lab 6
* Devices: TMS320F2812, TMS320F2811, TMS320F2810
* Author: Technical Training Organization (TTO), Texas Instruments
* History:
*   11/10/03 - original (based on DSP281x header files v1.00)
**********************************************************************/

#include "DSP281x_Device.h"
#include "lab.h"


/**********************************************************************
* Function: InitEv()
*
* Description: Initializes the Event Managers
**********************************************************************/
void InitEv(void)
{

/*** Configure the EXTCON registers ***/
	EvaRegs.EXTCONA.all = 0x0001;
/*
 bit 15-4      0's:    reserved
 bit 3         0:      EVSOCE, 0 = disable EV start of ADC conversion output
 bit 2         0:      QEPIE, 0 = disable CAP3_QEPI as index input
 bit 1         0:      QEPIQUAL, 0 = CAP3_QEPI qual disabled
 bit 0         1:      INDCOE, 1 = independent compare enable
*/

	EvbRegs.EXTCONB.all = 0x0001;
/*
 bit 15-4      0's:    reserved
 bit 3         0:      EVSOCE, 0 = disable EV start of ADC conversion output
 bit 2         0:      QEPIE, 0 = disable CAP6_QEPI as index input
 bit 1         0:      QEPIQUAL, 0 = CAP6_QEPI qual disabled
 bit 0         1:      INDCOE, 1 = independent compare enable
*/

/*** Disable and clear all event manager interrupts ***/
	EvaRegs.EVAIMRA.all = 0x0000;		// Disable all EVA group A interrupts
	EvaRegs.EVAIMRB.all = 0x0000;		// Disable all EVA group B interrupts
    EvaRegs.EVAIMRC.all = 0x0000;		// Disable all EVA group C interrupts
    EvaRegs.EVAIFRA.all = 0xFFFF;       // Clear all EVA group A interrupts
    EvaRegs.EVAIFRB.all = 0xFFFF;		// Clear all EVA group B interrupts
    EvaRegs.EVAIFRC.all = 0xFFFF;		// Clear all EVA group C interrupts

	EvbRegs.EVBIMRA.all = 0x0000;		// Disable all EVB group A interrupts
	EvbRegs.EVBIMRB.all = 0x0000;		// Disable all EVB group B interrupts
    EvbRegs.EVBIMRC.all = 0x0000;		// Disable all EVB group C interrupts
    EvbRegs.EVBIFRA.all = 0xFFFF;       // Clear all EVB group A interrupts
    EvbRegs.EVBIFRB.all = 0xFFFF;		// Clear all EVB group B interrupts
    EvbRegs.EVBIFRC.all = 0xFFFF;		// Clear all EVB group C interrupts

/*** Configure the GPTCONA register ***/
	EvaRegs.GPTCONA.all = 0x0400;
/*
 bit 15        0:      reserved
 bit 14        0:      T2STAT, read-only
 bit 13        0:      T1STAT, read-only
 bit 12        0:      T2CTRIPE, 0=disable timer2 compare trip
 bit 11        0:      T1CTRIPE, 0=disable timer1 compare trip
 bit 10-9      10:     T2TOADC, 10 = timer2 period flag starts ADC
 bit 8-7       00:     T1TOADC
 bit 6         0:      TCOMPOE, 0 = Hi-z all timer compare outputs
 bit 5         0:      T2COMPOE, 0 = timer2 compare HI-z'd
 bit 4         0:      T1COMPOE, 0 = timer1 compare HI-z'd
 bit 3-2       00:     T2PIN, 00 = forced low
 bit 1-0       00:     T1PIN, 00 = forced low
*/


/*** Configure Timer 2 to trigger the ADC at a 50KHz rate ***/
	EvaRegs.T2CON.all = 0x0000;			// Disable timer
	EvaRegs.T2CNT = 0x0000;				// Clear timer counter
    EvaRegs.T2PR = 2999;				// Set timer period

	EvaRegs.T2CON.all = 0x1040;			//enable timer
/*
 bit 15-14     00:     FREE/SOFT, 00 = stop immediately on emulator suspend
 bit 13        0:      reserved
 bit 12-11     10:     TMODEx, 10 = continuous-up count mode
 bit 10-8      000:    TPSx, 111 = x/1 prescaler
 bit 7         0:      T2SWT1, 0 = use own TENABLE bit
 bit 6         1:      TENABLE, 1 = enable timer
 bit 5-4       00:     TCLKS, 00 = HSPCLK is clock source
 bit 3-2       00:     TCLD, 00 = reload compare reg on underflow
 bit 1         0:      TECMPR, 0 = enable timer compare
 bit 0         0:      SELT1PR, 0 = use own period register
*/

} // end InitEv()


/*** end of file *****************************************************/
